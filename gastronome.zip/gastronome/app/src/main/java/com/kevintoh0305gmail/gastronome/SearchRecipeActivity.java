package com.kevintoh0305gmail.gastronome;

import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.io.FileReader;
import java.lang.reflect.Array;
import java.util.ArrayList;

public class SearchRecipeActivity extends AppCompatActivity {

    EditText txtSearch;
    RecyclerView rvSearchRecipes;
    ImageButton btnBack;
    FirebaseDatabase firebaseDatabase;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search_recipe);
        txtSearch = findViewById(R.id.txtSearchRecipeName);
        rvSearchRecipes = findViewById(R.id.rvSearchRecipes);
        btnBack = findViewById(R.id.btnSearchRecipeBack);
        firebaseDatabase = FirebaseDatabase.getInstance();

        txtSearch.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                String searchQuery = txtSearch.getText().toString();
                GetSearchResults(GetRecipes(), searchQuery);
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });


        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }

    public ArrayList<Recipe> GetRecipes() {
        final ArrayList<Recipe> data = new ArrayList<>();
        firebaseDatabase.getReference("Recipes").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                for(DataSnapshot ds : dataSnapshot.getChildren())
                {
                    data.add(ds.getValue(Recipe.class));
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Log.d("Database Error", databaseError.getCode() + " : " + databaseError.getMessage());
            }
        });
        return data;
    }

    public void GetSearchResults(ArrayList<Recipe> data, String searchQuery) {
        ArrayList<Recipe> results = new ArrayList<>();
        for (int i = 0; i < data.size(); i++)
        {
            if(data.get(i).getTitle().toLowerCase().equals(searchQuery.toLowerCase()))
            {
                results.add(data.get(i));
            }
        }
        RecipeAdapter recipeAdapter = new RecipeAdapter(this, results);
        rvSearchRecipes.setAdapter(recipeAdapter);
        LinearLayoutManager manager = new LinearLayoutManager(this);
        rvSearchRecipes.setLayoutManager(manager);
        rvSearchRecipes.setItemAnimator(new DefaultItemAnimator());
    }
}
